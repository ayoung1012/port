import React, { useState } from 'react'
import './Main.css'
import './Mobile.css'

function puzzle (){
    const [modalData , setModalData] = useState(null)
}
const Mobile = () => {
    return (
        <div className='mo_allbox'>
            <header>
                <h1>GWON AH YEONG</h1>
            </header>

            <div className='mo_box'>

                <div className='contents_box1'>
                <div className='box1'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_g.png" alt="mo_g" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>ABOUT</p>
                    </div>
                </div>

                <div className='box2'></div>

                <div className='box3'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_j.png" alt="mo_j" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>SKILL</p>
                    </div>
                </div>
                </div>

                <div className='contents_box2'>
                <div className='box4'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_t.png" alt="mo_t" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>CRETIFICATE</p>
                    </div>
                </div>

                <div className='box5'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_b.png" alt="mo_b" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>WEATHER</p>
                    </div>
                </div>

                <div className='box6'>
                    <div className='b_text'>
                        <p>CLONE  <br /> CODING</p>
                    </div>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_c.png" alt="mo_c" />
                        </figure>
                    </div>
                </div>
                </div>


                <div className='contents_box3'>
                <div className='box7'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_a.png" alt="mo_a" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>BRANDING</p>
                    </div>
                </div>

                <div className='box8'></div>

                <div className='box9'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_s.png" alt="mo_s" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>SUPREME</p>
                    </div>
                </div>
                </div>



                <div className='contents_box4'>
                <div className='box10'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_w.png" alt="mo_W" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>UIUX</p>
                    </div>
                </div>

                <div className='box11'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_ca.png" alt="mo_ca" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>LEICA</p>
                    </div>
                </div>

                <div className='box12'>
                    <div className='b_img'>
                        <figure>
                            <img src="./img/mo_h.png" alt="mo_h" />
                        </figure>
                    </div>
                    <div className='b_text'>
                        <p>CONTACT</p>
                    </div>
                </div>
                </div>

                <div className='contents'>
                    <figure>
                        <img src="./img/mob_con.png" alt="mob_con" />
                    </figure>
                    <button type='button'>닫기</button>
                </div>
            </div>
        </div>
    )
}

export default Mobile